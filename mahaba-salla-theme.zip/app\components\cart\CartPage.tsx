import { useCallback, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { SallaConditionalOffer } from '@salla.sa/twilight-components-react/conditional-offer';
import { SallaOffer } from '@salla.sa/twilight-components-react/offer';
import { HookSlot, usePageConfig } from '@salla.sa/twilight-theme-engine/hooks';
import { useTranslation } from '@salla.sa/twilight-theme-engine/i18n';
import { Breadcrumb, NoContent } from '@salla.sa/twilight-theme-engine/common';
import { CartSummary, SeoCartWidget } from '@salla.sa/twilight-theme-engine/cart';
import { useTwilight } from '@salla.sa/twilight-theme-engine/providers';
import { CartSkeleton } from '@salla.sa/twilight-theme-engine/skeleton';
import { loyalty } from '@salla.sa/twilight-theme-engine/api/loyalty';
import { cart } from '@salla.sa/twilight-theme-engine/api/cart';
import type { CartPageProps } from '@salla.sa/twilight-theme-engine/routes/cart';
import { CartItem } from './CartItem';

/** Whether a failed request was answered 404 (the engine's API client throws ky's `HTTPError`). */
function isNotFound(error: unknown): boolean {
  return (error as { response?: { status?: number } } | null)?.response?.status === 404;
}

/**
 * Theme fork of the engine `CartPage`.
 *
 * Same data flow as upstream, plus a column-heading row above the items
 * (Products (N) · Quantity · Total) so the flat {@link CartItem} rows read as a
 * table, and an error state with a retry when the cart can't be loaded
 * (upstream keeps its skeleton up for good). A cart the API no longer knows
 * (404) is dropped from the SDK and shown empty. Upgrade notes: `FORKS.md`.
 */
function CartPageContent({ page }: CartPageProps) {
  const { store } = useTwilight();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  // Tells the SDK this is the cart page on a direct load, so `<salla-product-options>`
  // pre-checks each item's selected option.
  usePageConfig(page);
  const { data: loyaltyPoints } = useQuery(loyalty.queries.points());

  const cartIdQuery = useQuery(cart.queries.currentId());
  const cartId = cartIdQuery.data;

  const cartQuery = useQuery({
    ...cart.queries.detail(cartId!),
    enabled: !!cartId,
  });
  const cartData = cartQuery.data;

  // Refetch after a row mutates its quantity / gets deleted — the SDK doesn't
  // push cart changes back into React, so item totals and the summary would
  // otherwise stay stale until a page reload.
  const refetchCart = useCallback(() => {
    if (cartId != null) {
      queryClient.invalidateQueries({ queryKey: cart.queries.detail(cartId).queryKey });
    }
  }, [cartId, queryClient]);

  // Belt-and-suspenders: also refetch on any SDK cart event that does fire.
  // Root on/off: onUpdated registers a wrapper that only offUpdated can remove.
  useEffect(() => {
    window.salla?.event?.on?.('cart::updated', refetchCart);
    return () => {
      window.salla?.event?.off?.('cart::updated', refetchCart);
    };
  }, [refetchCart]);

  // The SDK's cart id names a cart the API no longer has (`cart/<id>` answered 404).
  const cartGone = isNotFound(cartQuery.error);

  // Drop that cart from the SDK (its stored id and cookies), so the next add to
  // cart starts a new one instead of failing against the old id.
  useEffect(() => {
    if (!cartGone) return;
    // `reset` is on the SDK's cart, but not in the engine's `SallaCart` type.
    (window.salla?.cart as { reset?: () => void } | undefined)?.reset?.();
  }, [cartGone]);

  // A failed request leaves its data undefined, so without this the skeleton
  // stayed up for good (e.g. `cart/<id>` answering an error).
  const failed = cartIdQuery.isError || (cartQuery.isError && !cartGone);
  // The SDK knew of no cart, or the API no longer has it.
  const noCart = (cartIdQuery.isSuccess && cartId == null) || cartGone;

  if (failed) {
    return (
      <div className="container">
        <Breadcrumb page={page} />
        <div className="no-content-placeholder">
          <i className="sicon-shopping-bag icon"></i>
          <p>{t('common.errors.error_occurred', 'Something went wrong')}</p>
          <button
            type="button"
            className="btn btn--outline-primary btn--rounded-full"
            onClick={() => {
              if (cartIdQuery.isError) cartIdQuery.refetch();
              else cartQuery.refetch();
            }}
          >
            {t('common.elements.try_again', 'Try again')}
          </button>
        </div>
      </div>
    );
  }

  if (!noCart && (cartId == null || cartData === undefined)) {
    return <CartSkeleton />;
  }

  // No cart: it was already turned into an order, shown empty like Twig.
  if (noCart || !cartData || cartData.items.length === 0) {
    return (
      <div className="container">
        <Breadcrumb page={page} />
        <NoContent
          icon="sicon-shopping-bag"
          message={t('pages.cart.empty_cart', 'Your cart is empty')}
          actionLabel={t('common.elements.back_home', 'Back to Home')}
          actionUrl="/"
        />
      </div>
    );
  }

  return (
    <div className="container">
      {/* Analytics — no visible UI, fires GTM checkout events */}
      <SeoCartWidget cart={cartData} />

      <Breadcrumb page={page} />
      <h1 className="sr-only">{t('common.titles.cart', 'Cart')}</h1>
      <SallaConditionalOffer />

      <HookSlot name="cart:start" />

      <div className="pt-5 flex flex-col items-start lg:flex-row pb-6 lg:pb-20">
        <div className="main-content w-full lg:w-[calc(100%-384px)]">
          <HookSlot name="cart:items.start" context={{ cartItems: cartData.items }} />

          <div className="cart-titles hidden md:flex rtl:space-x-reverse md:space-x-12 items-center border-b border-gray-200 pb-4 text-sm font-bold text-gray-900 mb-5">
            <span className="flex-1">
              {t('blocks.cart.products', 'Products')} ({cartData.items.length})
            </span>
            <span className="flex gap-6 md:gap-8">
              <span className="w-[120px] text-center">
                {t('pages.products.quantity', 'Quantity')}
              </span>
              <span>{t('blocks.cart.item_total', 'Total')}</span>
              <span className="w-5" aria-hidden="true"></span>
            </span>
          </div>

          {cartData.items.map((item, index) => (
            <CartItem key={item.id} item={item} isFirst={index === 0} onMutated={refetchCart} />
          ))}

          {cartData.options?.length > 0 && (
            <div className="cart-options">
              {cartData.options.map((option) => (
                <form
                  key={option.id}
                  className="first:pt-5 relative"
                  onChange={(e) => window.salla?.form.onChange('cart.updateItem', e)}
                  id={`item-${option.id}`}
                >
                  <input type="hidden" name="id" value={option.id} />
                  <input type="hidden" name="quantity" value={option.quantity} />
                  {option.options && option.options.length > 0 && (
                    // Raw element, like CartItem: the wrapper sets `options` too late and it renders empty.
                    <salla-product-options
                      key={JSON.stringify(option.options)}
                      options={JSON.stringify(option.options)}
                      product-id={option.id}
                    />
                  )}
                </form>
              ))}
            </div>
          )}

          <SallaOffer />
          <HookSlot name="cart:items.end" />
        </div>

        <CartSummary
          cart={cartData}
          applyCouponEnabled={store.settings?.cart?.apply_coupon_enabled}
          taxAmount={cartData.tax_amount}
          key={cartData.id}
          loyalty={cartData.loyalty}
          gift={cartData.gift}
          loyaltyPoints={loyaltyPoints ?? undefined}
        />
      </div>

      <HookSlot name="cart:end" />
    </div>
  );
}

export function CartPage(props: CartPageProps) {
  return <CartPageContent {...props} />;
}
