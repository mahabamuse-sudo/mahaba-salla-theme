import type { ReactNode } from 'react';
import { SallaMenu } from '@salla.sa/twilight-components-react/menu';
import { useTwilight } from '@salla.sa/twilight-theme-engine/providers';
import { useTranslation } from '@salla.sa/twilight-theme-engine/i18n';
import {
  Call02Icon,
  ChevronDownIcon,
  LanguagesIcon,
  Mail01Icon,
  MapPinIcon,
  Money01Icon,
} from '../icons';
import { openStoreSwitcher, type StoreSwitcher } from '../../lib/storeSwitchers';

/** One topnav trigger: leading icon, current-selection label, caret. */
function TopnavAction({
  icon,
  label,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className="site-header__topnav-action"
      aria-haspopup="dialog"
      onClick={onClick}
    >
      {icon}
      <span className="site-header__topnav-action-label">{label}</span>
      <ChevronDownIcon className="site-header__topnav-caret" aria-hidden="true" />
    </button>
  );
}

/**
 * The store's phone and email at the end of the top bar. Rendered here rather
 * than by `<salla-contacts is-header>`, which draws nothing until the SDK has
 * loaded and then pushed the switchers aside; these come with the page.
 */
function TopnavContacts({ phone, email }: { phone?: string; email?: string }) {
  if (!phone && !email) return null;

  return (
    <div className="site-header__topnav-contacts" data-testid="store-header-contacts">
      {phone && (
        <a href={`tel:${phone}`} className="site-header__topnav-contact">
          <Call02Icon className="site-header__topnav-icon" aria-hidden="true" />
          <span className="unicode" dir="ltr">
            {phone}
          </span>
        </a>
      )}
      {email && (
        <a href={`mailto:${email}`} className="site-header__topnav-contact">
          <Mail01Icon className="site-header__topnav-icon" aria-hidden="true" />
          <span>{email}</span>
        </a>
      )}
    </div>
  );
}


/**
 * Top bar for the "default" header layout — the footer menu on the start side
 * (unless the merchant turns `important_links` off, as in the engine Header) and
 * the language / branch / currency switchers on the end side. Desktop only
 * (`lg+`); on smaller screens the header collapses to the shared mobile bar.
 * Each opens through `openStoreSwitcher` (`lib/storeSwitchers.ts`): the
 * shared modals on the web, the app's own sheets for language and currency
 * inside the Salla app. Styling: `header.scss`
 * (`.site-header__topnav`).
 */
export function HeaderTopnav() {
  const { t, languageName } = useTranslation();
  const { store, currency, theme } = useTwilight();
  // Declared in `twilight.json` with a default of on, so only an explicit `false` hides it.
  const showImportantLinks = theme?.settings?.important_links !== false;

  const currencyLabel = currency?.name || currency?.symbol || currency?.code || 'SAR';
  const scopeLabel = store?.scope?.name || t('blocks.header.branches', 'Branches');
  const announcement = t(
    'theme.header.announcement',
    'Free shipping on orders over SAR 300 — signature gift wrapping included'
  );

  const actions: { key: StoreSwitcher; show: boolean; icon: ReactNode; label: string }[] = [
    {
      key: 'language',
      show: !!store?.settings?.is_multilingual,
      icon: <LanguagesIcon className="site-header__topnav-icon" aria-hidden="true" />,
      label: languageName,
    },
    {
      key: 'branch',
      show: !!store?.scope,
      icon: <MapPinIcon className="site-header__topnav-icon" aria-hidden="true" />,
      label: scopeLabel,
    },
    {
      key: 'currency',
      show: !!store?.settings?.currencies_enabled,
      icon: <Money01Icon className="site-header__topnav-icon" aria-hidden="true" />,
      label: currencyLabel,
    },
  ];

  return (
    <div className="site-header__topnav">
      <div className="container site-header__topnav-inner">
        <div className="site-header__topnav-menu-slot">
          {showImportantLinks && (
            <SallaMenu
              source="footer"
              topnav
              className="site-header__topnav-menu"
              suppressHydrationWarning
            />
          )}
        </div>

        <p className="site-header__announcement">{announcement}</p>

        <div className="site-header__topnav-actions">
          <salla-bullet-delivery-tag data-testid="store-header-bullet-delivery-desktop" />
          {actions
            .filter((action) => action.show)
            .map((action) => (
              <TopnavAction
                key={action.key}
                icon={action.icon}
                label={action.label}
                onClick={() => openStoreSwitcher(action.key)}
              />
            ))}
          <TopnavContacts phone={store?.contacts?.phone} email={store?.contacts?.email} />
        </div>
      </div>
    </div>
  );
}
